<?php

namespace Database\Seeders;

use App\Models\Asignatura;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;

class AsignaturaSeeder extends Seeder
{
    private $asignaturas=["Matemáticas","Lengua","Inglés","Ciencias Naturales"];
    public function run(): void
    {
        foreach($this->asignaturas as $asignatura){
            $a = new Asignatura();
            $a->nombre = $asignatura;
            $a->save();
        }
        $this->command->info('Tabla de asignaturas inicializada con datos');
    }
}
