<?php

namespace Database\Seeders;

use App\Models\Alumno;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;

class AlumnoSeeder extends Seeder
{
    private $alumnos = [
        ['nombre' => 'Juan', 'apellidos' => 'Pérez López', 'edad' => 18, 'imagen'=>'prueba.jpg', 'dni'=>'12345678A'],
            ['nombre' => 'María', 'apellidos' => 'Gómez Rodríguez', 'edad' => 19, 'imagen'=>'prueba.jpg', 'dni'=>'12345678B'],
            ['nombre' => 'Ana', 'apellidos' => 'Martínez Sánchez', 'edad' => 20, 'imagen'=>'prueba.jpg', 'dni'=>'12345678C'],
            ['nombre' => 'Carlos', 'apellidos' => 'García Torres', 'edad' => null, 'imagen'=>'prueba.jpg', 'dni'=>'12345678D'],
            ['nombre' => 'Laura', 'apellidos' => 'Fernández Ruiz', 'edad' => 22, 'imagen'=>'prueba.jpg', 'dni'=>'12345678E'],
            ['nombre' => 'Marta', 'apellidos' => 'López Jiménez', 'edad' => null, 'imagen'=>'prueba.jpg', 'dni'=>'12345678F'],
            ['nombre' => 'Pedro', 'apellidos' => 'Rodríguez Gómez', 'edad' => 25, 'imagen'=>'prueba.jpg', 'dni'=>'12345678G'],
    ];
    public function run(): void
    {
        foreach ($this->alumnos as $alumno) {
            $a = new Alumno();
            $a->nombre = $alumno['nombre'];
            $a->apellidos = $alumno['apellidos'];
            $a->edad = $alumno['edad'];
            $a->imagen = $alumno['imagen'];
            $a->dni = $alumno['dni'];
            $a->save();
        }
        $this->command->info('Tabla de alumnos inicializada con datos');
    }
}
