<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class AlumnosAsignaturasSeeder extends Seeder
{
    private $alumnoAsignaturas = [
        ['alumno_id' => 1, 'asignatura_id' => 1],
        ['alumno_id' => 1, 'asignatura_id' => 2],
        ['alumno_id' => 2, 'asignatura_id' => 1],
        ['alumno_id' => 2, 'asignatura_id' => 3],
        ['alumno_id' => 3, 'asignatura_id' => 2],
        ['alumno_id' => 3, 'asignatura_id' => 3],
        ['alumno_id' => 4, 'asignatura_id' => 1],
        ['alumno_id' => 4, 'asignatura_id' => 4],
        ['alumno_id' => 5, 'asignatura_id' => 4],
        ['alumno_id' => 6, 'asignatura_id' => 3],
        ['alumno_id' => 6, 'asignatura_id' => 1],
        ['alumno_id' => 7, 'asignatura_id' => 2],
    ];
    public function run(): void
    {
        foreach ($this->alumnoAsignaturas as $alumnoAsignatura) {
            DB::table('alumno_asignatura')->insert($alumnoAsignatura);
        }
        $this->command->info('Tabla de alumno_asignatura inicializada con datos');
    }
}
