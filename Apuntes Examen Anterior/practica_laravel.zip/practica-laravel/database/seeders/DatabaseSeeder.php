<?php

namespace Database\Seeders;

use App\Models\User;
use Illuminate\Support\Facades\DB;
// use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;

class DatabaseSeeder extends Seeder
{
    /**
     * Seed the application's database.
     */
    public function run(): void
    {

        DB::table('alumnos')->delete();
        DB::table('asignaturas')->delete();
        DB::table('alumno_asignatura')->delete();
        $this->call(AlumnoSeeder::class);
        $this->call(AsignaturaSeeder::class);
        $this->call(AlumnosAsignaturasSeeder::class);
        User::factory(5)->create();

        User::factory()->create([
            'name' => 'Test User',
            'email' => 'prueba@example.com',
            'password' => bcrypt('naranco_'),
        ]);

        // User::factory()->create([
        //     'name' => 'Test User',
        //     'email' => 'test@example.com',
        // ]);
    }
}
