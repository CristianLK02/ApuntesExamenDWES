<?php

use App\Http\Controllers\AlumnoController;
use App\Http\Controllers\AsignaturasController;
use App\Http\Controllers\ProfileController;
use Illuminate\Support\Facades\Route;

Route::get('/', [AlumnoController::class,"index"])->name('alumnos.index');
Route::get('/asignaturas', [AsignaturasController::class,"index"])->name('asignaturas.index');

Route::get('/alumno/crear', [AlumnoController::class,"create"])->name('alumnos.create')->middleware('auth');
Route::post('/alumno', [AlumnoController::class,"store"])->name('alumnos.store')->middleware('auth');

Route::get('/alumno/{alumno}/editar', [AlumnoController::class,"edit"])->name('alumnos.edit')->middleware('auth');
Route::get('/alumno/{alumno}', [AlumnoController::class,"show"])->name('alumnos.show')->middleware('auth');
Route::delete('/alumno/{alumno}', [AlumnoController::class,"destroy"])->name('alumnos.destroy')->middleware('auth');

Route::put('/alumno/{alumno}', [AlumnoController::class,"update"])->name('alumnos.update')->middleware('auth');
Route::get('/asignaturas/{asignatura}', [AsignaturasController::class,"show"])->name('asignaturas.show')->middleware('auth');

Route::get('/dashboard', function () {
    return view('dashboard');
})->middleware(['auth', 'verified'])->name('dashboard');

Route::middleware('auth')->group(function () {
    Route::get('/profile', [ProfileController::class, 'edit'])->name('profile.edit');
    Route::patch('/profile', [ProfileController::class, 'update'])->name('profile.update');
    Route::delete('/profile', [ProfileController::class, 'destroy'])->name('profile.destroy');
});

require __DIR__.'/auth.php';
