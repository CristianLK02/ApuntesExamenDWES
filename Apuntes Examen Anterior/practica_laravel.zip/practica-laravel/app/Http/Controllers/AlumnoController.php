<?php

namespace App\Http\Controllers;

use App\Models\Alumno;
use App\Models\Asignatura;
use Illuminate\Http\Request;

class AlumnoController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        $alumnos = Alumno::paginate(5);
        return view('alumnos.index', compact('alumnos'));
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        $asignaturas = Asignatura::all();
        return view('alumnos.create',compact('asignaturas'));
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        $alumno = new Alumno();
        $alumno->nombre = $request->nombre;
        $alumno->apellidos = $request->apellidos;
        $alumno->edad = $request->edad;
        $alumno->dni = $request->dni;
        if ($request->hasFile('imagen')) {
            $alumno->imagen = $request->imagen->store('', 'alumnos');
        }
        $alumno->save();
        $alumno->asignaturas()->attach($request->asignaturas);
        return redirect()->route('alumnos.show', $alumno);
    }

    /**
     * Display the specified resource.
     */
    public function show(Alumno $alumno)
    {
        return view('alumnos.show', compact('alumno'));
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(Alumno $alumno)
    {
        $asignaturas = Asignatura::all();
        return view('alumnos.edit', compact('alumno','asignaturas'));
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, Alumno $alumno)
    {
        $alumno->nombre = $request->nombre;
        $alumno->apellidos = $request->apellidos;
        $alumno->edad = $request->edad;
        $alumno->dni = $alumno->dni;
        if ($request->hasFile('imagen')) {
            $alumno->imagen = $request->imagen->store('', 'alumnos');
        }
        $alumno->asignaturas()->sync($request->asignaturas);
        $alumno->save();
        return redirect()->route('alumnos.show', $alumno);
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(Alumno $alumno)
    {
        $alumno->delete();
        return redirect()->route('alumnos.index');
    }
}
