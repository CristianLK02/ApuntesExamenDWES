<?php $__env->startSection('titulo'); ?>
    Alumnos
<?php $__env->stopSection(); ?>
<?php $__env->startSection('contenido'); ?>
<style>
    img {
            width: 100%;
            height: 400px;
            border-radius: 20px;
        }
</style>
<div class="row">
    <!-- Columna de la imagen -->

    <!-- Columna de los detalles -->
    <div class="col-md-12">
        <h1 class="display-3">Datos de la asignatura</h1>
        <p><b>Nombre:</b> <?php echo e($asignatura->nombre); ?></p>
        <p><b>Alumnos que lo cursan:</b></p>
        <ul>
            <?php $__currentLoopData = $asignatura->alumnos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $alumno): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li><a href="<?php echo e(route('alumnos.show',$alumno)); ?>"> <?php echo e($alumno->nombre); ?> <?php echo e($alumno->apellidos); ?> </a></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
        
        
        <!-- Botones -->
        
        
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/practica-laravel/resources/views/asignaturas/show.blade.php ENDPATH**/ ?>