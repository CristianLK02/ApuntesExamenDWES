<?php $__env->startSection('titulo'); ?>
    Alumnos
<?php $__env->stopSection(); ?>
<?php $__env->startSection('contenido'); ?>
<style>
    img {
            width: 100%;
            height: 400px;
            object-fit: cover;
        }
</style>
    <div class="row d-flex justify-content-between align-items-center">
        <div class="col-md-6">
            <h1>Lista de alumnos</h1>
        </div>
        <div class="col-md-6 text-end">
            <?php if(auth()->guard()->check()): ?>
            <a href="<?php echo e(route('alumnos.create')); ?>" class="btn btn-primary"><i class="bi bi-plus"></i> Añadir alumno</a>
            <?php else: ?>
            <a class="btn btn-primary disabled"><i class="bi bi-plus"></i> Añadir alumno</a>
            <?php endif; ?>
            
        </div>
    </div>
    
    <div class="row">
        <table class="table">
            <thead>
                <tr>
                    <th scope="col">DNI</th>
                    <th scope="col">Nombre</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $alumnos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $clave => $alumno): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <th scope="row"><?php echo e($alumno->dni); ?></th>
                        <td>
                            <a href="<?php echo e(route('alumnos.show', $alumno)); ?>">
                                <?php echo e($alumno->nombre); ?> <?php echo e($alumno->apellidos); ?>

                            </a>
                        </td>
                    </tr>
                    
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
        
        <?php echo e($alumnos->links('pagination::bootstrap-5')); ?>

    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/practica-laravel/resources/views/alumnos/index.blade.php ENDPATH**/ ?>