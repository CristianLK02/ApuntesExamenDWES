<nav class="navbar navbar-expand-lg navbar-dark fixed-top bg-dark">
    <div class="container-fluid">
    <a class="navbar-brand" href="<?php echo e(url('/')); ?>">Gestión de Alumnos</a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarSupportedContent">
      <ul class="navbar-nav me-auto mb-2 mb-lg-0">
        

        <li class="nav-item">
          <a href="<?php echo e(route('alumnos.index')); ?>" class="nav-link <?php echo e(request()->routeIs('alumnos.*') && !request()->routeIs('alumnos.create')? ' active' : ''); ?>">Listado de alumnos</a>
        </li>
        <li class="nav-item">
          <a href="<?php echo e(route('asignaturas.index')); ?>" class="nav-link <?php echo e(request()->routeIs('asignaturas.*') && !request()->routeIs('asignaturas.create')? ' active' : ''); ?>">Listado de asignaturas</a>
        </li>
        
      </ul>
      
      <?php if(Auth::check() ): ?>

          <form id="formularioBusqueda" class="d-flex">
            <input id="busqueda" class="form-control mr-sm-3" type="text" placeholder="Buscar" aria-label="Buscar">
            <ul id="resultados"></ul>
          </form>

          <ul class="navbar-nav navbar-right">
            <li class="nav-item">
              <a href="<?php echo e(route('profile.edit')); ?>"  class="nav-link">
                <?php echo e(Auth::user()->name); ?>

              </a>
            </li>
              <li class="nav-item">
                  <a href="<?php echo e(route('logout')); ?>"  class="nav-link"
                    onclick="event.preventDefault();
                     document.getElementById('logout-form').submit();" >
                      <span class="glyphicon glyphicon-off"></span>
                      Cerrar sesión
                  </a>
                  <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                      <?php echo csrf_field(); ?>
                  </form>
              </li>
          </ul>
      <?php else: ?>
          <ul class="navbar-nav navbar-right">
              <li class="nav-item">
                <a href="<?php echo e(url('login')); ?>" class="nav-link">Iniciar sesión</a>
              </li>
          </ul>
      <?php endif; ?>
    </div>
  </div>
  </nav>
<?php /**PATH /var/www/practica-laravel/resources/views/layouts/navbar.blade.php ENDPATH**/ ?>