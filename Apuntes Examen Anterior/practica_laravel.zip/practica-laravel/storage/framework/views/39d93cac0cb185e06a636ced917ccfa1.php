<?php $__env->startSection('titulo'); ?>
    Alumnos
<?php $__env->stopSection(); ?>
<?php $__env->startSection('contenido'); ?>
<style>
    img {
            width: 100%;
            height: 400px;
            border-radius: 20px;
        }
</style>
<div class="row">
    <!-- Columna de la imagen -->
    <div class="col-md-3">
        <img src="<?php echo e(asset('assets/img/' . $alumno->imagen)); ?>" class="img-fluid" alt="<?php echo e($alumno->nombre); ?>">
        
    </div>

    <!-- Columna de los detalles -->
    <div class="col-md-9">
        <h1 class="display-3">Datos del alumno</h1>
        <p><b>Nombre:</b> <?php echo e($alumno->nombre); ?></p>
        <p><b>Apellidos:</b> <?php echo e($alumno->apellidos); ?></p>
        <p><b>DNI:</b> <?php echo e($alumno->dni); ?></p>
        <?php if($alumno->edad != null): ?>
        <p><b>Edad:</b> <?php echo e($alumno->edad); ?></p>
        <?php else: ?>
        <p><b>Edad:</b> No especificada</p>
        <?php endif; ?>
        <span><b>Cursos en los que participa:</b></span>
        <ul>
          <?php $__currentLoopData = $alumno->asignaturas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $asignatura): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <li><?php echo e($asignatura->nombre); ?></li>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
        
        
        <!-- Botones -->
        <div class="mt-4 d-flex gap-1">
            <a href="<?php echo e(route('alumnos.edit',$alumno)); ?>" class="btn btn-primary">Editar datos</a>
                <button type="button" class="btn btn-danger" data-bs-toggle="modal" data-bs-target="#modalEliminar">
                    Eliminar
                  </button>
            <a href="<?php echo e(route('alumnos.index')); ?>" class="btn btn-outline-dark"><i
                    class="bi bi-chevron-left"></i>Volver a la lista</a>

        </div>
        <div class="modal fade" id="modalEliminar" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
            <div class="modal-dialog">
              <div class="modal-content">
                <div class="modal-header">
                  <h1 class="modal-title fs-5" id="exampleModalLabel">¿Estás seguro eliminarlo?</h1>
                  <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                  El alumno <b><?php echo e($alumno->nombre); ?> <?php echo e($alumno->apellidos); ?></b> será eliminado de forma permanente.
                </div>
                <div class="modal-footer">
                  <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancelar</button>
                    <form action="<?php echo e(route('alumnos.destroy', $alumno)); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('delete'); ?>
                        <button type="submit" class="btn btn-danger">Eliminar permanentemente</button>
                    </form>
                </div>
              </div>
            </div>
          </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/practica-laravel/resources/views/alumnos/show.blade.php ENDPATH**/ ?>