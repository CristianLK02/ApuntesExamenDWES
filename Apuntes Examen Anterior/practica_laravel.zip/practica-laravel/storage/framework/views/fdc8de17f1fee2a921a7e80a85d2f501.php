<?php $__env->startSection('titulo'); ?>
    Gestión de Alumnos
<?php $__env->stopSection(); ?>
<?php $__env->startSection('contenido'); ?>
    <div class="row">
        <div class="offset-md-3 col-md-6">
            <div class="card">
                <div class="card-header text-center">
                    Crear alumno
                </div>
                <div class="card-body" style="padding:30px">
                    <form method="POST" action="<?php echo e(route('alumnos.store')); ?>" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <div class="mb-3">
                            <label for="titulo">Nombre</label>
                            <input type="text" name="nombre" id="nombre" class="form-control" required>
                        </div>
                        <div class="mb-3">
                            <label for="titulo">Apellidos</label>
                            <input type="text" name="apellidos" id="apellidos" class="form-control" required>
                        </div>
                        <div class="mb-3">
                            <label for="dni">DNI</label>
                            <input type="text" name="dni" id="dni" class="form-control" required>
                        </div>
                        <div class="mb-3">
                            <label for="periodo">Edad</label>
                            <input type="number" name="edad" id="edad" class="form-control" required>
                        </div>
                        <div class="mb-3">
                            <label for="periodo">Cursos</label>
                            <select name="asignaturas[]" id="asignaturas" class="form-control" multiple>
                                <?php $__currentLoopData = $asignaturas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $asignatura): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($asignatura->id); ?>"
                                    ><?php echo e($asignatura->nombre); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                        <div class="mb-3">
                            <label for="imagen">Imagen</label>
                            <input type="file" name="imagen" class="form-control">
                        </div>
                        <div class="mb-3 text-center">
                            <button type="submit" class="btn btn-success" style="padding:8px 100px;margintop:25px;">
                                Agregar alumno
                            </button>
                        </div>
                        
                    </form>
                </div>
            </div>
        <?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/practica-laravel/resources/views/alumnos/create.blade.php ENDPATH**/ ?>