<?php $__env->startSection('titulo'); ?>
    Alumnos
<?php $__env->stopSection(); ?>
<?php $__env->startSection('contenido'); ?>
<style>
    img {
            width: 100%;
            height: 400px;
            object-fit: cover;
        }
</style>
    <h1>Lista de asignaturas</h1>
    <div class="row">
        <table class="table">
            <thead>
                <tr>
                    <th scope="col">Nombre</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $asignaturas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $clave => $asignatura): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td>
                            <a href="<?php echo e(route('asignaturas.show', $asignatura)); ?>">
                                <?php echo e($asignatura->nombre); ?>

                            </a>
                        </td>
                    </tr>
                    
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/practica-laravel/resources/views/asignaturas/index.blade.php ENDPATH**/ ?>