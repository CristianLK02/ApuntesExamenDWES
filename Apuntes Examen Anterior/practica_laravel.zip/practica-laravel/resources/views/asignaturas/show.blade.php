@extends('layouts.master')
@section('titulo')
    Alumnos
@endsection
@section('contenido')
<style>
    img {
            width: 100%;
            height: 400px;
            border-radius: 20px;
        }
</style>
<div class="row">
    <!-- Columna de la imagen -->

    <!-- Columna de los detalles -->
    <div class="col-md-12">
        <h1 class="display-3">Datos de la asignatura</h1>
        <p><b>Nombre:</b> {{ $asignatura->nombre }}</p>
        <p><b>Alumnos que lo cursan:</b></p>
        <ul>
            @foreach ($asignatura->alumnos as $alumno)
            <li><a href="{{ route('alumnos.show',$alumno)}}"> {{$alumno->nombre}} {{$alumno->apellidos}} </a></li>
            @endforeach
        </ul>
        
        
        <!-- Botones -->
        {{-- <div class="mt-4 d-flex gap-1">
            <a href="{{ route('alumnos.edit',$alumno) }}" class="btn btn-primary"><i
                class="bi bi-chevron-left"></i>Editar datos</a>
                <button type="button" class="btn btn-danger" data-bs-toggle="modal" data-bs-target="#modalEliminar">
                    Eliminar
                  </button>
            <a href="{{ route('alumnos.index') }}" class="btn btn-outline-dark"><i
                    class="bi bi-chevron-left"></i>Volver a la lista</a>

        </div> --}}
        
    </div>
</div>
@endsection