@extends('layouts.master')
@section('titulo')
    Alumnos
@endsection
@section('contenido')
<style>
    img {
            width: 100%;
            height: 400px;
            object-fit: cover;
        }
</style>
    <h1>Lista de asignaturas</h1>
    <div class="row">
        <table class="table">
            <thead>
                <tr>
                    <th scope="col">Nombre</th>
                </tr>
            </thead>
            <tbody>
                @foreach ($asignaturas as $clave => $asignatura)
                    <tr>
                        <td>
                            <a href="{{ route('asignaturas.show', $asignatura) }}">
                                {{ $asignatura->nombre }}
                            </a>
                        </td>
                    </tr>
                    
                @endforeach
            </tbody>
        </table>
    </div>
@endsection