@extends('layouts.master')
@section('titulo')
    Gestión de Alumnos
@endsection
@section('contenido')
    <div class="row">
        <div class="offset-md-3 col-md-6">
            <div class="card">
                <div class="card-header text-center">
                    Crear alumno
                </div>
                <div class="card-body" style="padding:30px">
                    <form method="POST" action="{{route('alumnos.store')}}" enctype="multipart/form-data">
                        @csrf
                        <div class="mb-3">
                            <label for="titulo">Nombre</label>
                            <input type="text" name="nombre" id="nombre" class="form-control" required>
                        </div>
                        <div class="mb-3">
                            <label for="titulo">Apellidos</label>
                            <input type="text" name="apellidos" id="apellidos" class="form-control" required>
                        </div>
                        <div class="mb-3">
                            <label for="dni">DNI</label>
                            <input type="text" name="dni" id="dni" class="form-control" required>
                        </div>
                        <div class="mb-3">
                            <label for="periodo">Edad</label>
                            <input type="number" name="edad" id="edad" class="form-control" required>
                        </div>
                        <div class="mb-3">
                            <label for="periodo">Cursos</label>
                            <select name="asignaturas[]" id="asignaturas" class="form-control" multiple>
                                @foreach ($asignaturas as $asignatura)
                                    <option value="{{$asignatura->id}}"
                                    >{{$asignatura->nombre}}</option>
                                @endforeach
                            </select>
                        </div>
                        <div class="mb-3">
                            <label for="imagen">Imagen</label>
                            <input type="file" name="imagen" class="form-control">
                        </div>
                        <div class="mb-3 text-center">
                            <button type="submit" class="btn btn-success" style="padding:8px 100px;margintop:25px;">
                                Agregar alumno
                            </button>
                        </div>
                        {{-- TODO: Cerrar formulario --}}
                    </form>
                </div>
            </div>
        @endsection
