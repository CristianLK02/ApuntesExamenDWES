@extends('layouts.master')
@section('titulo')
    Alumnos
@endsection
@section('contenido')
<style>
    img {
            width: 100%;
            height: 400px;
            object-fit: cover;
        }
</style>
    <div class="row d-flex justify-content-between align-items-center">
        <div class="col-md-6">
            <h1>Lista de alumnos</h1>
        </div>
        <div class="col-md-6 text-end">
            @auth
            <a href="{{ route('alumnos.create') }}" class="btn btn-primary"><i class="bi bi-plus"></i> Añadir alumno</a>
            @else
            <a class="btn btn-primary disabled"><i class="bi bi-plus"></i> Añadir alumno</a>
            @endauth
            
        </div>
    </div>
    
    <div class="row">
        <table class="table">
            <thead>
                <tr>
                    <th scope="col">DNI</th>
                    <th scope="col">Nombre</th>
                </tr>
            </thead>
            <tbody>
                @foreach ($alumnos as $clave => $alumno)
                    <tr>
                        <th scope="row">{{ $alumno->dni }}</th>
                        <td>
                            <a href="{{ route('alumnos.show', $alumno) }}">
                                {{ $alumno->nombre }} {{ $alumno->apellidos }}
                            </a>
                        </td>
                    </tr>
                    
                @endforeach
            </tbody>
        </table>
        {{-- Crea una paginacion --}}
        {{$alumnos->links('pagination::bootstrap-5')}}
    </div>
@endsection