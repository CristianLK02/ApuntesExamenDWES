@extends('layouts.master')
@section('titulo')
    Gestión de Alumnos
@endsection
@section('contenido')
    <div class="row">
        <div class="offset-md-3 col-md-6">
            <div class="card">
                <div class="card-header text-center">
                    Editar alumno
                </div>
                <div class="card-body" style="padding:30px">
                    <form method="POST" action="{{route('alumnos.update',$alumno)}}" enctype="multipart/form-data">
                        @csrf
                        @method('put')
                        <div class="mb-3">
                            <label for="titulo">Nombre</label>
                            <input type="text" name="nombre" id="nombre" class="form-control" required value="{{ $alumno->nombre }}">
                        </div>
                        <div class="mb-3">
                            <label for="titulo">Apellidos</label>
                            <input type="text" name="apellidos" id="apellidos" class="form-control" required value="{{ $alumno->apellidos }}">
                        </div>
                        <div class="mb-3">
                            <label for="dni">DNI</label>
                            <input type="text" name="dni" id="dni" class="form-control" required value="{{ $alumno->dni }}" readonly disabled>
                        </div>
                        <div class="mb-3">
                            <label for="periodo">Edad</label>
                            <input type="number" name="edad" id="edad" class="form-control" required value="{{$alumno->edad}}">
                        </div>
                        <div class="mb-3">
                            <label for="periodo">Cursos</label>
                            <select name="asignaturas[]" id="asignaturas" class="form-control" multiple>
                                @foreach ($asignaturas as $asignatura)
                                    <option value="{{$asignatura->id}}"
                                        @if ($alumno->asignaturas->contains($asignatura->id))
                                            selected
                                        @endif
                                    >{{$asignatura->nombre}}</option>
                                @endforeach
                            </select>
                        </div>
                        <div class="mb-3">
                            <label for="imagen">Imagen</label>
                            <input type="file" name="imagen" class="form-control">
                        </div>
                        <div class="mb-3 text-center">
                            <button type="submit" class="btn btn-success" style="padding:8px 100px;margintop:25px;">
                                Modificar alumno
                            </button>
                        </div>
                        {{-- TODO: Cerrar formulario --}}
                    </form>
                </div>
            </div>
        @endsection
